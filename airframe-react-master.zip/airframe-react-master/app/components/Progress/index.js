import { Progress } from './Progress';

export default Progress;
