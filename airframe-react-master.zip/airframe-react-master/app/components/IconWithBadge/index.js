import { IconWithBadge } from './IconWithBadge';

export default IconWithBadge;
