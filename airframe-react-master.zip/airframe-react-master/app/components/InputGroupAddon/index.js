import { InputGroupAddon } from './InputGroupAddon'; 

export default InputGroupAddon;