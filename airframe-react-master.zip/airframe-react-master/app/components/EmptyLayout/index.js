import { EmptyLayout } from './EmptyLayout';
import { EmptyLayoutSection } from './EmptyLayoutSection';

EmptyLayout.Section = EmptyLayoutSection;

export default EmptyLayout;
