import Success from './Success';

export default Success;