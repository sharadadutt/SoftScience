import LockScreen from './LockScreen';

export default LockScreen;