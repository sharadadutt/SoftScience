import Confirmation from './Confirmation';

export default Confirmation;