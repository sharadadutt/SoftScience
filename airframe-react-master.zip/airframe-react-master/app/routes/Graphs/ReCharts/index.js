import ReCharts from './ReCharts';

export default ReCharts;
