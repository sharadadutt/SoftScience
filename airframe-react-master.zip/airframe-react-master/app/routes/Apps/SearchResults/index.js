import SearchResults from './SearchResults';

export default SearchResults; 