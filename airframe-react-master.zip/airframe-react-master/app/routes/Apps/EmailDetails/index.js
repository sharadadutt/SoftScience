import EmailDetails from './EmailDetails';

export default EmailDetails; 