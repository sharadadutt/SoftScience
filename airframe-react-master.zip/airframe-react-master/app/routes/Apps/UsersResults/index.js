import UsersResults from './UsersResults';

export default UsersResults; 