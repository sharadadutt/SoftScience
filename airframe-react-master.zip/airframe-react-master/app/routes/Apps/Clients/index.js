import Clients from './Clients';

export default Clients; 