import TasksDetails from './TasksDetails';

export default TasksDetails; 