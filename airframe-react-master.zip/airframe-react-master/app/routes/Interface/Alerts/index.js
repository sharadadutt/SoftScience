import Alerts from './Alerts';

export default Alerts; 