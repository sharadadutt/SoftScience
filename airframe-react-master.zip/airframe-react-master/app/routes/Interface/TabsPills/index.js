import TabsPills from './TabsPills';

export default TabsPills; 