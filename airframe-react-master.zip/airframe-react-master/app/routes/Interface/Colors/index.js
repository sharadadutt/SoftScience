import Colors from './Colors';

export default Colors; 