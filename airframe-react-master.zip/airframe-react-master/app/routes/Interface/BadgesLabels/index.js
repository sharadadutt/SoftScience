import BadgesLabels from './BadgesLabels';

export default BadgesLabels; 