import Paginations from './Paginations';

export default Paginations; 