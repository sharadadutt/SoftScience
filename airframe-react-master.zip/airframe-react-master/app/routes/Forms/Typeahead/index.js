import { Typeahead } from './Typeahead';

export default Typeahead;
