import { TextMask } from './TextMask';

export default TextMask;
