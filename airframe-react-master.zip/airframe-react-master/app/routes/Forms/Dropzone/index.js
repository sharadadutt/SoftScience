import { Dropzone } from './Dropzone';

export default Dropzone;
