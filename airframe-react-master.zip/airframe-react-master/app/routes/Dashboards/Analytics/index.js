import { Analytics } from './Analytics';

export default Analytics; 